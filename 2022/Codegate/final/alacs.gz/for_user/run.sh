#!/bin/bash
cd /home/ctf
timeout 60 ./alacs