#!/bin/bash

cd /home/ctf/
./microjinkernel